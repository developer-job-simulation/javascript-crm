import { makeTable } from './ui'
// Entry point to our program
makeTable();